# Phiên bản mã hóa nguồn mở
# Copyright (C) 2020 Shinigami
# Phiên bản v1.0~b2
# Gõ lệnh cloneapp <app> đẻ chạy