
window.addEventListener("load", function() { 
   //document.body.style.width='100%';
   //document.body.style.height='100%';
}, false);


var chX = 0;


function init(){
	//updateClock();
	//setInterval("updateClock();", 600000);
	setInterval("checkFor13();", 600000);
	setTimeout(initWidget, 500);
}

function initWidget(){
	checkSettings();
	document.getElementById("in").addEventListener("keyup", function(event) {
    	event.preventDefault();
    	if (event.keyCode === 13) {
        	document.getElementById("sIcon").click();
    	}
	});
	
	checkFor13();
	
}

function checkFor13(){
	checkWeather();
		
	if(rem)
		checkRem();
		
	if(!rem)
		checkEvent();
		
	if(mu === 1){
		checkMusic();
	}
}

function checkSettings(){
	
	document.documentElement.style.setProperty('--primary', C1);//
	document.documentElement.style.setProperty('--secondary', C2);
	document.documentElement.style.setProperty('--third', C3);
	document.documentElement.style.setProperty('--four', C4);
	
	if(se === 0){
		document.getElementById('_searchCont').style.display = 'none';
	}
	document.getElementById('_searchCont').style.top = seY + 'px';
	
	
	if(mu === 0){
		document.getElementById('_musCont').style.display = 'none';
	}
	document.getElementById('_musCont').style.top = muY + '%';
	
	
	if(we === 0){
		document.getElementById('_weaCont').style.display = 'none';
	}
	document.getElementById('_weaCont').style.top = weY + '%';
	document.getElementById('_weaCont').style.left = weX + '%';
	
	
	if(ba === 0){
		document.getElementById('_battCont').style.display = 'none';
	}
	document.getElementById('_battCont').style.top = baY + '%';
	document.getElementById('_battCont').style.left = baX + '%';
	
	
	if(ca === 0){
		document.getElementById('eveCont').style.display = 'none';
	}
	document.getElementById('eveCont').style.top = caY + '%';
	document.getElementById('eveCont').style.left = caX + '%';
	
}

//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	/*var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}*/
	
	
	//document.getElementById("_time").innerHTML = currentHours + ":" + currentMinutes1;
		
	document.getElementById("_month").innerHTML = shortmonths[currentTime.getMonth()];
	document.getElementById("_date").innerHTML = currentDate;
		
}


function Search(){
	var input = document.getElementById("in").value;
	if(input.trim() !== ''){
		window.location = 'xeninfo:openurl:google.com/search?q=' + input;
	}
}


//--------------------------- XENINFO ---------------------------
function mainUpdate(type){
	if(chX > 3){
		if(type === "weather"){
			checkWeather();
		}else if(type === "reminders"){
			if(rem)
				checkRem();
		}else if(type === "events"){
			if(!rem)
				checkEvent();
		}else if (type === "music"){
			if(mu === 1){
				checkMusic();
			}
		}else if (type === "battery"){
			updateBattery();	  	
		}
	}else{
		chX++;
	}
}

//------------------------- REMINDERS FUNCTIONS ---------------------------
function checkRem(){
	if(reminders.length > 0){
		document.getElementById('_eve').innerHTML = '';
	}else{
		document.getElementById('_eve').innerHTML = 'No Reminders';
	}
    for (var i = 0; i < reminders.length; i++) {
        document.getElementById('_eve').innerHTML += reminders[i].title + " - " + reminders[i].dueDate + "</br>";
    }
}

//------------------------- EVENTS FUNCTIONS ---------------------------
function checkEvent(){
	if(events.length > 0){
		document.getElementById('_eve').innerHTML = 'Up Next';
		
		var myNode = document.getElementById("_events");
		while (myNode.firstChild) {
			myNode.removeChild(myNode.firstChild);
		}
		
		for (var i = 0; i < events.length; i++) {
			var _box = document.createElement('div'),
				_time = document.createElement('span'),
				_title = document.createElement('span');
				
			_box.style.cssText = "position:relative;\
								 height:70px;";
				
			if(events[i].isAllDay){
				_time.innerHTML = 'all day';
			}else{
				_time.innerHTML = transformTime(events[i].startTimeTimestamp) + ' - ' + transformTime(events[i].endTimeTimestamp);// + ' | ' + events[i].date;
			}
			_time.style.cssText = "position:absolute;\
								  color:" + C2 + ";\
								  top:0px;\
								  width:100%;\
								  font-size:12px;";
			_box.appendChild(_time);
			
			_title.innerHTML = events[i].title;
			_title.style.cssText = "position:absolute;\
								   font-family:'medium';\
								   top:16px;\
								   color:" + C2 + ";\
								   width:100%;\
								   height:55px;\
								   overflow:hidden;\
								   font-size:15px;";
			_box.appendChild(_title);
			
			document.getElementById('_events').appendChild(_box);
		}
	}else{
		document.getElementById('_eve').innerHTML = 'No Events';
		var myNode2 = document.getElementById("_events");
		while (myNode2.firstChild) {
			myNode2.removeChild(myNode2.firstChild);
		}
	}
}

function transformTime(unix){
	var date = new Date(unix*1000);
	var hours = date.getHours();
	var minutes = "0" + date.getMinutes();
	
	var formattedTime = hours + ':' + minutes.substr(-2);
	
	return formattedTime;
}


//------------------------- BATTERY FUNCTIONS ---------------------------
function updateBattery() {
	"use strict";

	var batt = document.getElementById("percent");
	//console.log("battery");
	//batteryPercent = 30;
	batt.innerHTML = batteryPercent + "%";
	
	document.getElementById("battIn").style.opacity = batteryPercent / 100;
}


//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	//document.getElementById('weatherIcon').src = 'weather/' + weather.conditionCode + '.png';
	document.getElementById('condition').innerHTML = weather.condition;
	document.getElementById('tempe').innerHTML = weather.temperature;
	
}

