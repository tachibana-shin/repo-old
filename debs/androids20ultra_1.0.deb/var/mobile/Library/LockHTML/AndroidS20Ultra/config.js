var MainColor = "Red";
var SecondaryColor = "DarkBlue";
var ZoomLevel = 70;
