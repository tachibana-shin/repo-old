#import "SAConfettiView.h"
#import <QuartzCore/QuartzCore.h>

@interface UIImage (Addition)
+(UIImage *)imageNamed:(NSString *)name inBundle:(NSBundle *)bundle;
@end

@implementation SAConfettiView

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

-(void)setup {
    self.backgroundColor = [UIColor clearColor];
    self.colors = @[[UIColor colorWithRed:0.95 green:0.40 blue:0.27 alpha:1.0],
                [UIColor colorWithRed:1.00 green:0.78 blue:0.36 alpha:1.0],
                [UIColor colorWithRed:0.48 green:0.78 blue:0.64 alpha:1.0],
                [UIColor colorWithRed:0.30 green:0.76 blue:0.85 alpha:1.0],
                [UIColor colorWithRed:0.58 green:0.39 blue:0.55 alpha:1.0]];
    self.intensity = 0.5;
    self.type = Confetti;
}
-(void)startConfetti {
    self.emitter = [[CAEmitterLayer alloc] init];
    self.emitter.emitterPosition = CGPointMake(self.center.x, 0);
    self.emitter.emitterShape = kCAEmitterLayerLine;
    self.emitter.emitterSize = CGSizeMake(self.frame.size.width, 1);


    NSMutableArray *cells = [[NSMutableArray alloc] init];
    for (UIColor *color in self.colors) {
        CAEmitterCell *cell = [self confettiWithColor:color];
        [cells addObject:cell];
    }

    self.emitter.emitterCells = cells;
    [self.layer addSublayer:self.emitter];
}

-(void)stopConfetti {
    self.emitter.birthRate = 0;
}

-(UIImage *)imageForType:(ConfettiType)imageType {
    NSString *fileName;

    switch (self.type) {
        case Confetti:
            fileName = @"confetti";
            break;
        case Star:
            fileName = @"Star";
            break;
        case Triangle:
            fileName = @"triangle";
            break;
        case Diamond:
            fileName = @"diamond";
            break;
        case Custom:
            return self.customImage;
        default:
            break;

    }

    UIImage *image = [UIImage imageNamed:fileName inBundle:[NSBundle bundleWithPath:@"/Library/PreferenceBundles/HKSettings.bundle/"]];
    if (image) {
        return image;
    } else {
        return nil;
    }
}

-(CAEmitterCell *)confettiWithColor:(UIColor *)color {
    CAEmitterCell *confetti = [[CAEmitterCell alloc] init];
    confetti.birthRate = 6.0 * self.intensity;
    confetti.lifetime = 14.0 * self.intensity;
    confetti.lifetimeRange = 0;
    confetti.color = color.CGColor;
    confetti.velocity = (350.0 * self.intensity);
    confetti.velocityRange = (80.0 * self.intensity);
    confetti.emissionLongitude = (M_PI);
    confetti.emissionRange = (M_PI_4);
    confetti.spin = (3.5 * self.intensity);
    confetti.spinRange = (4.0 * self.intensity);
    confetti.scaleRange = (self.intensity);
    confetti.scaleSpeed = (-0.1 * self.intensity);
    UIImage *confettiImage = [self imageForType:self.type];
    confetti.contents = (__bridge id _Nullable)(confettiImage.CGImage);
    return confetti;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
   UIView *hitView = [super hitTest:point withEvent:event];
   if (hitView == self) return nil;
   return hitView;
}

@end
