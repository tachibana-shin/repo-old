#import <UIKit/UIKit.h>

typedef enum {
    Confetti,
    Triangle,
    Star,
    Diamond,
    Custom,

} ConfettiType;

@interface SAConfettiView : UIView
-(void)startConfetti;
-(void)stopConfetti;

@property NSArray *colors;
@property float intensity;
@property CAEmitterLayer *emitter;
@property ConfettiType type;
@property UIImage *customImage;
@end
