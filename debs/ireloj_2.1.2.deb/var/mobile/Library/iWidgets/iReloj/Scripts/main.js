window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
var currentDate1 = currentTime.getDate() - 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours == 0 ) ? "12" : currentHours;
	currentHours = ( currentHours == 13 ) ? "01" : currentHours;
	currentHours = ( currentHours == 14 ) ? "02" : currentHours;
	currentHours = ( currentHours == 15 ) ? "03" : currentHours;
	currentHours = ( currentHours == 16 ) ? "04" : currentHours;
	currentHours = ( currentHours == 17 ) ? "05" : currentHours;
	currentHours = ( currentHours == 18 ) ? "06" : currentHours;
	currentHours = ( currentHours == 19 ) ? "07" : currentHours;
	currentHours = ( currentHours == 20 ) ? "08" : currentHours;
	currentHours = ( currentHours == 21 ) ? "09" : currentHours;
	currentHours = ( currentHours == 22 ) ? "10" : currentHours;
	currentHours = ( currentHours == 23 ) ? "11" : currentHours;
	currentHours = ( currentHours == 24 ) ? "12" : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("second").innerHTML = segs[currentTime.getSeconds()];
document.getElementById("second1").innerHTML = segs1[currentTime.getSeconds()];
document.getElementById("today").innerHTML = today[currentTime.getHours()];
document.getElementById("today1").innerHTML = today1[currentTime.getHours()];
document.getElementById("weekday").innerHTML = shortdays[currentTime.getDay()];
document.getElementById("date").innerHTML = date[currentDate1];
document.getElementById("date1").innerHTML = dateplus[currentDate1];
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];
document.getElementById("nombre").innerHTML = Name;

document.getElementById('hour').style.color = ClockColor;
document.getElementById('minute').style.color = ClockColor;
document.getElementById('second').style.color = DotsColor;
document.getElementById('weekday').style.color = CalendarColor;
document.getElementById('month').style.color = CalendarColor;
document.getElementById('date').style.color = DateColor;
document.getElementById('date1').style.color = DateColor;
document.getElementById('today').style.color = RegardsColor;
document.getElementById('today1').style.color = RegardsColor;
document.getElementById('nombre').style.color = NameColor;
document.getElementById('temp').style.color = TemperatureColor;
document.getElementById('text').style.color = SeparatorColor;
document.getElementById('LevelDisplay').style.color = BatteryColor;
document.getElementById('texto').style.color = BatteryColor;

document.getElementById('blurs').style = "-webkit-backdrop-filter: blur(" + Blur + ");";

cajon.style.backgroundColor = SquareOneColor;
cajon1.style.backgroundColor = SquareTwoColor;
blurs.style.backgroundColor = SquareThreeColor;

marco.style.borderColor = BorderColor;

}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}