var Scale = "1"; 
var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; 
var refreshrate = 10; // update interval of weather, in minutes
var WeatherIcon = 1; // 1= white, 2= black
var TextColor1 = "azure"; 
var TextColor2 = "silver"; 
var BlurBackground = true; 
var HideBackground = false; 
var BackgroundColor = "#333343"; 
